package Controller;

public class TraenerController {

    public void runProgram() {
    }
}
