package Controller;

public class KassererController {


    public void runProgram() {
    }
}
