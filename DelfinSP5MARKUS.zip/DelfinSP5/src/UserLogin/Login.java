package UserLogin;

public interface Login {
    void login();

}
